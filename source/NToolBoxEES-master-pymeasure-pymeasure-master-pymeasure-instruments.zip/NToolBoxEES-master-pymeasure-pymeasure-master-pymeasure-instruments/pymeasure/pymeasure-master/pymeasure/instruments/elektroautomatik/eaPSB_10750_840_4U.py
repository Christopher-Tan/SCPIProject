# Basic functions for EA - Elektro-Automatik EA-PSB 10750-120 bidirectional Power Supply
#
# R.Scheuss, 02.04.2025
#
# Connected with LAN cable
#
#
#
# INFO: - In case of communication trouble, check:
#       - By default, the TCP communication turns off after 5sec. Is 'TCP keep-alive (internal) enabled in 'Menu->Communication->Timeouts'
#         (should be done automatically during object creation)
#       - Is in 'Menu->Communication->Ethernet(internal)'  DHCP enabled?
#
# WARNING: - To turn on the output, the device has to be in remoteControl-mode
#            In case of emergency, the device cannot turned off at front panel (because of remote mode)
#            Always set back to localMode after turning on does not work. By changing back to localMode, the output turns off
#            => to turn back to localMode on front panel, touch display -> Exit remote control 
#
# HOW TO USE: - see at the end of this file in main()


from pymeasure.instruments import Instrument

class EAPSB_10750_120(Instrument):

    def __init__(self, adapter, timeout=1000, **kwargs):
        super().__init__(adapter, "EAPSB_10750_120", timeout=timeout, **kwargs)


    def getDeviceIdent(self):
        return self.ask("*IDN?")
    
    def getRemoteControl(self):
        return self.ask("SYST:LOCK:OWN?")
    
    def remoteControl(self):
        self.write("SYST:LOCK ON")

    def localControl(self):
        self.write("SYST:LOCK OFF")


    # VOLTAGE COMMANDS ---------------------------------------------------------
    # get voltage at the terminals
    def getVoltage(self):
        return self.ask("MEAS:VOLT?").strip().replace("V", "").strip()  


    # get max voltage the source is capable of
    def getMaxVoltage(self):
        return self.ask("SYST:NOM:VOLT?").strip().replace("V", "").strip()  


    def setVoltage(self, voltage):
        self.write("SOUR:VOLT " + str(voltage))


# CURRENT COMMANDS ---------------------------------------------------------
    # get current at the terminals
    def getCurrent(self):
        return self.ask("MEAS:CURR?").strip().replace("A", "").strip()   
    
    # get the max current the source is capable of
    def getMaxCurrent(self):
        return self.ask("SYST:NOM:CURR?")

    # set the source current
    def setSourceCurrent(self, current):
        self.write("SOUR:CURR " + str(current))

    # set the sink current
    def setSinkCurrent(self, current):
        self.write("SINK:CURR " + str(-current))

# POWER COMMANDS ---------------------------------------------------------
    # get power at the terminals
    def getPower(self):
        return self.ask("MEAS:POW?").strip().replace("W", "").strip() 
    
    # get the max positive power the source is capable of
    def getMaxPower(self):
        return self.ask("SYST:NOM::POW?")


    # set the source power
    def setSourcePower(self, current):
        self.write("SOUR:POW " + str(current))

    # set the sink power
    def setSinkPower(self, current):
        self.write("SINK:POW " + str(-current))


    def enableOutput(self):
        self.write("OUTPUT ON")


    def disableOutput(self):
        self.write("OUTPUT OFF")


if __name__=="__main__":

    myEA = EAPSB_10750_120('TCPIP0::PSies041.ost.ch::5025::SOCKET', write_termination='\n', read_termination='\n')

    print("Device ID: " + myEA.getDeviceIdent())

    print("Voltage =  " + myEA.getVoltage())
    print("Max Voltage =  " + myEA.getMaxVoltage())

    print("Current =  " + myEA.getCurrent())
    print("Max Current =  " + myEA.getMaxCurrent())

    print("Power =  " + myEA.getCurrent())
    print("Max Power =  " + myEA.getMaxCurrent()) 

    print("owner =  " + myEA.getRemoteControl())

    myEA.remoteControl()
    myEA.setVoltage(10)
    myEA.setSourceCurrent(11.258)
    myEA.setSinkCurrent(-10.3216)
    myEA.setSourcePower(100)
    myEA.setSinkPower(-200)

    myEA.enableOutput()

    myEA.setVoltage(11.25)

    myEA.disableOutput()
    myEA.localControl()     # back to local to have the possibility to control at front panel


    print("End")