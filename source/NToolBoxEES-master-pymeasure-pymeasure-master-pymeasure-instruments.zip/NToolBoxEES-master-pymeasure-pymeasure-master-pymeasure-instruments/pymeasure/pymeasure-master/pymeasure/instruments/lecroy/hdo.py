#
# This file is part of the PyMeasure package.
#
# Copyright (c) 2013-2017 PyMeasure Developers
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
#

from pymeasure.instruments.instrument import ActiveDSOInstrument
import lecroyparser

class HDO(ActiveDSOInstrument):
    """ Represents the HDO Oscilloscope
    and provides a high-level for interacting with the instrument
    """
    COMM_HEADER_LIST = ["LONG", "SHORT", "OFF"]
    COMM_FORMAT_BLOCK_FORMAT_LIST = ["DEF9"]
    COMM_FORMAT_DATA_TYPE_LIST = ["BYTE", "WORD"]
    COMM_FORMAT_ENCODING_LIST = ["BIN"]
    CHANNEL_LIST = [1, 2, 3, 4]
    ATTENUATION_LIST = [1, 2, 5, 10, 20, 25, 50, 100, 200, 500, 1000, 10000]
    CHANNEL_COUPLING_LIST = ["A1M", "D1M", "D50", "GND"]
    REFERENCE_CLOCK_SOURCE = ["INT", "EXT"]
    TRIGGER_COUPLING_LIST = ["AC", "DC", "LFREJ", "HFREJ"]
    TRIGGER_MODE_LIST = ["AUTO", "NORM", "SINGLE", "STOP"]
    TRIGGER_SLOPE_LIST = ["POS", "NEG"]
    TRIGGER_TYPE_LIST =["DROP", "EDGE", "GLIT","INTV", "PA", "RUNT", "SLEW", "SQ", "TEQ", "TEQ1", "TV", "SNG", "STD"]
    
    
    def __init__(self, address):
        super(HDO, self).__init__(
            address=address,
            name="LeCroy WaveRunner 606Zi Oscilloscope",
        )

        self.measurement = HDO.Measurement(self)

    def disconnect(self):
        return super(HDO, self).disconnect()

    def recall_setup_from_file(self, filename):
        """ Command to setup osci from file based on filename
        cmd = "RCPN DISK, HDD, FILE," + filename.
        """
        return self.write("%s" % ("RCPN DISK, HDD, FILE," + filename))

        # TODO: must be new implemented self.port.tty.StoreHardcopyToFile('TIFF', '', filename)
        # HDO.print_screen_tif= Instrument.control()

    id = ActiveDSOInstrument.id

    query_options = ActiveDSOInstrument.measurement(
        "*OPT?", "" "Query the scope options. """
    )

    timespan = ActiveDSOInstrument.control(
        "TIME_DIV?", "TIME_DIV %g",
        """ A floating point property that controls the timespan of the horizontal axis
        This property can be set.
        """
    )

    def set_save_path(self, path: str):
        # Ensure the path is valid
        cmd = f"DISK:PATH '{path}'"
        self.adapter.write(cmd)
    def close(self):
        self.adapterclose()

    def reset(self):
        cmd = "*RST"
        self.adapter.write(cmd)

    def arm(self):
        cmd = "ARM" 
        self.adapter.write(cmd)

    def stop(self):
        cmd = "STOP"
        self.adapter.write(cmd)

    def wait(self, time: float):
        assert time > 0, "Invalid time. Time must be greater than 0"
        cmd = f"WAIT {time}"
        self.adapter.write(cmd)

    def calibrate(self) -> int:
        cmd = "*CAL?"
        self.adapter.write(cmd)
        sleep(5)
        response = self.adapterread()
        return int(response)

    def set_comm_header(self, header: str):
        header = header.upper()
        assert header in self.COMM_HEADER_LIST, f"Invalid header value. Valid values are: {self.COMM_HEADER_LIST}"
        cmd = f"COMM_HEADER {header}"
        self.adapter.write(cmd)

    def get_comm_header(self) -> str:
        cmd = "COMM_HEADER?"
        response = self.adapter.ask(cmd).split(" ")
        return response[len(response) - 1]

    def set_comm_format(self, block_format: str, data_type: str, encoding: str):
        assert block_format in self.COMM_FORMAT_BLOCK_FORMAT_LIST, f"Invalid block format. Valid values are: {self.COMM_FORMAT_BLOCK_FORMAT_LIST}"
        assert data_type in self.COMM_FORMAT_DATA_TYPE_LIST, f"Invalid data type. Valid values are: {self.COMM_FORMAT_DATA_TYPE_LIST}"
        assert encoding in self.COMM_FORMAT_ENCODING_LIST, f"Invalid encoding. Valid values are: {self.COMM_FORMAT_ENCODING_LIST}"
        cmd = f"CFMT {block_format},{data_type},{encoding}"
        self.adapter.write(cmd)

    def get_comm_format(self) -> tuple[str, str, str]:
        cmd = "CFMT?"
        response = self.adapter.ask(cmd).split(",")
        return response[0], response[1], response[2]

    def set_auto_calibrate_enable(self, enable: bool):
        ena = "ON" if enable else "OFF"
        cmd = f"ACAL {ena}"
        self.adapter.write(cmd)
    
    def get_auto_calibrate_enable(self) -> bool:
        cmd = "ACAL?"
        return self.adapter.ask(cmd) == "ON"

    def auto_setup(self, channel: int = 0):
        if channel == 0:
            cmd = f"C1:ASET"
        else:
            assert channel in self.CHANNEL_LIST, f"Invalid channel. Valid channels are: {self.CHANNEL_LIST}"
            cmd = f"C{channel}:ASET FIND"
        self.adapter.write(cmd)

    def set_channel_attenuation(self, channel: int, attenuation: int):
        assert channel in self.CHANNEL_LIST, f"Invalid channel. Valid channels are: {self.CHANNEL_LIST}"
        assert attenuation in self.ATTENUATION_LIST, f"Invalid attenuation. Valid values are: {self.ATTENUATION_LIST}"
        cmd = f"C{channel}:ATTN {attenuation}"
        self.adapter.write(cmd)

    def get_channel_attenuation(self, channel: int) -> int:
        assert channel in self.CHANNEL_LIST, f"Invalid channel. Valid channels are: {self.CHANNEL_LIST}"
        cmd = f"C{channel}:ATTN?"
        return int(self.adapter.ask(cmd))

    def get_channel_bandwidth(self, channel: int) -> bool:
        assert channel in self.CHANNEL_LIST, f"Invalid channel. Valid channels are: {self.CHANNEL_LIST}"
        cmd = f"BWL?"
        response = self.adapter.ask(cmd).split(",")
        return response[2*channel - 1] == "ON"

    def set_channel_bandwidth(self, channel: int, enable: bool):
        assert channel in self.CHANNEL_LIST, f"Invalid channel. Valid channels are: {self.CHANNEL_LIST}"
        ena = "ON" if enable else "OFF"
        cmd = f"BWL {channel},{ena}"
        self.adapter.write(cmd)

    def set_channel_coupling(self, channel: int, coupling: str):
        assert channel in self.CHANNEL_LIST, f"Invalid channel. Valid channels are: {self.CHANNEL_LIST}"
        assert coupling in self.CHANNEL_COUPLING_LIST, f"Invalid coupling. Valid values are: {self.CHANNEL_COUPLING_LIST}"
        cmd = f"C{channel}:CPL {coupling}"
        self.adapter.write(cmd)

    def get_channel_coupling(self, channel: int) -> str:
        assert channel in self.CHANNEL_LIST, f"Invalid channel. Valid channels are: {self.CHANNEL_LIST}"
        cmd = f"C{channel}:CPL?"
        return self.adapter.ask(cmd)

    def set_channel_offset(self, channel: int, offset: float):
        assert channel in self.CHANNEL_LIST, f"Invalid channel. Valid channels are: {self.CHANNEL_LIST}"
        cmd = f"C{channel}:OFST {offset}"
        self.adapter.write(cmd)

    def get_channel_offset(self, channel: int) -> float:
        assert channel in self.CHANNEL_LIST, f"Invalid channel. Valid channels are: {self.CHANNEL_LIST}"
        cmd = f"C{channel}:OFST?"
        return float(self.adapter.ask(cmd))

    def set_channel_voltage_division(self, channel: int, division: float):
        assert channel in self.CHANNEL_LIST, f"Invalid channel. Valid channels are: {self.CHANNEL_LIST}"
        cmd = f"C{channel}:VDIV {division}"
        self.adapter.write(cmd)

    def get_channel_voltage_division(self, channel: int) -> float:
        assert channel in self.CHANNEL_LIST, f"Invalid channel. Valid channels are: {self.CHANNEL_LIST}"
        cmd = f"C{channel}:VDIV?"
        return float(self.adapter.ask(cmd))

    def get_memory_size(self) -> int:
        cmd = "MSIZ?"
        return int(self.adapter.ask(cmd))

    def set_memory_size(self, size: int):
        cmd = f"MSIZ {size}"
        self.adapter.write(cmd)

    def set_reference_clock_source(self, source: str):
        assert source in self.REFERENCE_CLOCK_SOURCE, f"Invalid source. Valid values are: {self.REFERENCE_CLOCK_SOURCE}"
        cmd = f"RCLK {source}"
        self.adapter.write(cmd)

    def set_reference_clock_source(self) -> str:
        cmd = "RCLK?"
        return self.adapter.ask(cmd)

    def set_sample_clock_source(self, source: str):
        assert source in self.REFERENCE_CLOCK_SOURCE, f"Invalid source. Valid values are: {self.REFERENCE_CLOCK_SOURCE}"
        cmd = f"SCLK {source}"
        self.adapter.write(cmd)

    def get_sample_clock_source(self) -> str:
        cmd = "SCLK?"
        return self.adapter.ask(cmd)

    def get_timebase(self) -> float:
        cmd = "TDIV?"
        return float(self.adapter.ask(cmd))

    def set_timebase(self, timebase: float):
        cmd = f"TDIV {timebase}"
        self.adapter.write(cmd)

    def force_trigger(self):
        cmd = "FRTR"
        self.adapter.write(cmd)

    def trigger(self):
        cmd = "*TRG"
        self.adapter.write(cmd)

    def set_trigger_coupling(self, channel: int, coupling: str):
        assert coupling in self.TRIGGER_COUPLING_LIST, f"Invalid coupling. Valid values are: {self.TRIGGER_COUPLING_LIST}"
        assert channel in self.CHANNEL_LIST, f"Invalid channel. Valid channels are: {self.CHANNEL_LIST}"
        cmd = f"C{channel}:TRCP {coupling}"
        self.adapter.write(cmd)

    def get_trigger_coupling(self, channel: int) -> str:
        assert channel in self.CHANNEL_LIST, f"Invalid channel. Valid channels are: {self.CHANNEL_LIST}"
        cmd = f"C{channel}:TRCP?"
        return self.adapter.ask(cmd)

    def set_trigger_delay(self, delay: float):
        cmd = f"TRDL {delay}"
        self.adapter.write(cmd)

    def get_trigger_delay(self) -> float:
        cmd = "TRDL?"
        return float(self.adapter.ask(cmd))

    def set_trigger_level(self, channel: int, level: float):
        assert channel in self.CHANNEL_LIST, f"Invalid channel. Valid channels are: {self.CHANNEL_LIST}"
        cmd = f"C{channel}:TRLV {level}"
        self.adapter.write(cmd)

    def get_trigger_level(self, channel: int) -> float:
        assert channel in self.CHANNEL_LIST, f"Invalid channel. Valid channels are: {self.CHANNEL_LIST}"
        cmd = f"C{channel}:TRLV?"
        return float(self.adapter.ask(cmd))

    def set_trigger_mode(self, mode: str):
    
        assert mode in self.TRIGGER_MODE_LIST, f"Invalid mode. Valid values are: {self.TRIGGER_MODE_LIST}"
        cmd = f"TRMD {mode}"
        self.adapter.write(cmd)

    def get_trigger_mode(self) -> str:
        cmd = "TRMD?"
        return self.adapter.ask(cmd)

    def set_trigger_slope(self, channel: int, slope: str):
        assert channel in self.CHANNEL_LIST, f"Invalid channel. Valid channels are: {self.CHANNEL_LIST}"
        assert slope in self.TRIGGER_SLOPE_LIST, f"Invalid slope. Valid values are: {self.TRIGGER_SLOPE_LIST}"
        cmd = f"C{channel}:TRSL {slope}"
        self.adapter.write(cmd)

    def get_trigger_slope(self, channel: int) -> str:
        assert channel in self.CHANNEL_LIST, f"Invalid channel. Valid channels are: {self.CHANNEL_LIST}"
        cmd = f"C{channel}:TRSL?"
        return self.adapter.ask(cmd)

    def set_trigger_source(self, source: int, type: str = "EDGE"):
        assert source in self.CHANNEL_LIST, f"Invalid channel. Valid channels are: {self.CHANNEL_LIST}"
        assert type in self.TRIGGER_TYPE_LIST, f"Invalid trigger type. Valid values are: {self.TRIGGER_TYPE_LIST}"
        cmd = f"TRSE {type},SR,C{source}"
        self.adapter.write(cmd)
    def get_trigger_type(self) -> str:
        """
        Abfragt den aktuellen Trigger-Typ vom Oszilloskop.
        :return: Der aktuelle Trigger-Typ als String (z.B. "EDGE", "DROP", "GLIT", etc.).
        """
        cmd = "TRSE?"
        response = self.adapter.ask(cmd)  # Antwort abrufen
        return response.strip()  
    
    def set_trigger(self, channel: int, type: str, slope: str = None, level: float = None, 
                    coupling: str = None, delay: float = None, mode: str = None, 
                    ht: str = None, ti: str = None, hv: str = None):
        """
        Setzt alle relevanten Trigger-Parameter. Unterstützt EDGE- und DROP-Trigger.

        :param channel: Kanalnummer für den Trigger
        :param type: Trigger-Typ (z. B. "EDGE", "DROP")
        :param slope: Trigger-Flanke ("POS" für steigende, "NEG" für fallende Flanke) (nur für EDGE)
        :param level: Trigger-Level in Volt (optional, je nach Trigger-Typ)
        :param coupling: Trigger-Kopplung ("AC", "DC", "LFREJ", "HFREJ") (optional)
        :param delay: Trigger-Verzögerung in Sekunden (optional)
        :param mode: Trigger-Modus ("AUTO", "NORM", "SINGLE", "STOP") (optional)
        :param ht: Holdoff Time (nur für DROP)
        :param ti: Time Interval (nur für DROP)
        :param hv: Holdoff Voltage (nur für DROP)
        """
        
        assert type in self.TRIGGER_TYPE_LIST, f"Invalid trigger type. Valid values are: {self.TRIGGER_TYPE_LIST}"
        
        if type == "EDGE":
            assert slope in self.TRIGGER_SLOPE_LIST, f"Invalid slope. Valid values are: {self.TRIGGER_SLOPE_LIST}"
            assert level is not None, "Level is required for EDGE trigger"
            
            self.set_trigger_source(channel, type)
            self.set_trigger_slope(channel, slope)
            self.set_trigger_level(channel, level)

        elif type == "DROP":
            assert hv is not None, "HT, TI, and HV are required for DROP trigger"
            
            cmd = f"TRSE DROP,SR,C{channel},HT,TI,HV,{hv}"
            self.adapter.write(cmd)
        
        else:
            self.set_trigger_source(channel, type)
        
        if coupling:
            self.set_trigger_coupling(channel, coupling)
        if slope:
            self.set_trigger_slope(channel, slope)
        if level:
           self.set_trigger_level(channel, level)

        if delay:
            self.set_trigger_delay(delay)
        
        if mode:
            self.set_trigger_mode(mode)

            
    def get_trigger(self, channel: int) -> dict:
        """
        Liest alle aktuellen Trigger-Einstellungen aus.

        :param channel: Kanalnummer für den Trigger
        :return: Dictionary mit allen Trigger-Einstellungen
        """
        return {
            "trigger": self.get_trigger_type(),
            "slope": self.get_trigger_slope(channel),
           # "level": self.get_trigger_level(channel),
            "coupling": self.get_trigger_coupling(channel),
            "delay": self.get_trigger_delay(),
            "mode": self.get_trigger_mode()
        }
    def set_waveform_config(self, sparsing:int = 0, n_points:int = 0, first_point:int = 0, segment_number:int = 0):
        cmd = f"WFSU SP,{sparsing},NP,{n_points},FP,{first_point},SN,{segment_number}"
        self.adapter.write(cmd)

    def get_waveform_config(self) -> tuple[int, int, int, int]:
        cmd = "WFSU?"
        response = self.adapter.ask(cmd).split(",")
        sparsing = int(response[1])
        n_points = int(response[3])
        first_point = int(response[5])
        segment_number = int(response[7])
        return sparsing, n_points, first_point, segment_number

    def get_waveform(self, channel: int):
        assert channel in self.CHANNEL_LIST, f"Invalid channel. Valid channels are: {self.CHANNEL_LIST}"
        cmd = f"C{channel}:WAVEFORM?"
        raw = self.adapter.ask_binary(cmd)
        data = lecroyparser.ScopeData(data=bytes(raw))
        return data

    def get_measurement_Px(self, num):
        """Use special access to Lecroy with VBS
        get the value of the ma"""
        value = self.adapter.ask("VBS? 'return=app.Measure.P%d.Out.Result.Value' " % num)
        return value

    def save_c1_trc(self, format="Excel", filename="Ires", filepath="D:\Hardcopy"):
        """Save C1 Analog Waveform
        format: "ASCII" (TXT), "Binary" (BIN), "Excel" (CSV), MathCad, MATLAB  
        filenname: "Ires"
        filepath: "D:\Hardcopy"  
        """
        self.adapter.write("VBS 'app.SaveRecall.Waveform.SaveSource = \"C1\"' ")
        self.adapter.write("VBS 'app.SaveRecall.Waveform.WaveformDir = \"%s\"'" %filepath)
        self.adapter.write("VBS 'app.SaveRecall.Waveform.WaveFormat = \"%s\"'"%format)
        self.adapter.write("VBS 'app.SaveRecall.Waveform.TraceTitle = \"%s\"'"%filename)
        self.adapter.write("VBS 'app.SaveRecall.Waveform.DoSave' ")
        """Wait until all traces are saved"""
        self.adapter.write("*OPC?")
        txt =  self.adapter.read()

    def save_c2_trc(self, format="Excel", filename="Ires", filepath="D:\Hardcopy"):
        """Save C2 Analog Waveform
        format: "ASCII" (TXT), "Binary" (BIN), "Excel" (CSV), MathCad, MATLAB  
        filenname: "Ires"
        filepath: "D:\Hardcopy"  
        """
        self.adapter.write("VBS 'app.SaveRecall.Waveform.SaveSource = \"C2\"' ")
        self.adapter.write("VBS 'app.SaveRecall.Waveform.WaveformDir = \"%s\"'" %filepath)
        self.adapter.write("VBS 'app.SaveRecall.Waveform.WaveFormat = \"%s\"'"%format)
        self.adapter.write("VBS 'app.SaveRecall.Waveform.TraceTitle = \"%s\"'"%filename)
        self.adapter.write("VBS 'app.SaveRecall.Waveform.DoSave' ")
        """Wait until all traces are saved"""
        self.adapter.write("*OPC?")
        txt =  self.adapter.read()

    def save_c3_trc(self, format="Excel", filename="Ires", filepath="D:\Hardcopy"):
        """Save C3 Analog Waveform
        format: "ASCII" (TXT), "Binary" (BIN), "Excel" (CSV), MathCad, MATLAB  
        filenname: "Ires"
        filepath: "D:\Hardcopy"  
        """
        self.adapter.write("VBS 'app.SaveRecall.Waveform.SaveSource = \"C3\"' ")
        self.adapter.write("VBS 'app.SaveRecall.Waveform.WaveformDir = \"%s\"'" %filepath)
        self.adapter.write("VBS 'app.SaveRecall.Waveform.WaveFormat = \"%s\"'"%format)
        self.adapter.write("VBS 'app.SaveRecall.Waveform.TraceTitle = \"%s\"'"%filename)
        self.adapter.write("VBS 'app.SaveRecall.Waveform.DoSave' ")
        """Wait until all traces are saved"""
        self.adapter.write("*OPC?")
        txt =  self.adapter.read()    

    def save_c4_trc(self, format="Excel", filename="Ires", filepath="D:\Hardcopy"):
        """Save C4 Analog Waveform
        format: "ASCII" (TXT), "Binary" (BIN), "Excel" (CSV), MathCad, MATLAB  
        filenname: "Ires"
        filepath: "D:\Hardcopy"  
        """
        self.adapter.write("VBS 'app.SaveRecall.Waveform.SaveSource = \"C4\"' ")
        self.adapter.write("VBS 'app.SaveRecall.Waveform.WaveformDir = \"%s\"'" %filepath)
        self.adapter.write("VBS 'app.SaveRecall.Waveform.WaveFormat = \"%s\"'"%format)
        self.adapter.write("VBS 'app.SaveRecall.Waveform.TraceTitle = \"%s\"'"%filename)
        self.adapter.write("VBS 'app.SaveRecall.Waveform.DoSave' ")
        """Wait until all traces are saved"""
        self.adapter.write("*OPC?")
        txt =  self.adapter.read()
    
    def save_all_displayed_trc(self):
        """Save "All Displayed" Analog Waveforms"""
        self.adapter.write("VBS 'app.SaveRecall.Waveform.SaveSource = \"AllDisplayed\"' ")
        self.adapter.write("VBS 'app.SaveRecall.Waveform.DoSave' ")
        """Wait until all traces are saved"""
        self.adapter.write("*OPC?")
        txt =  self.adapter.read()
    # def save_screen_to_file(self, filename):
        # """this function print the screen to HDD in Oscillo
        # I met some problem with StoreHardcopyToFile due to oscillo crash"""
        # #self.adapter.connection.StoreHardcopyToFile("TIFF", "", "D:\\HardCopy\\TIFFImage.tif")
        # self.adapter.write("VBS 'app.Hardcopy.EnableCounterSuffix = \"False\"' ")
        # self.adapter.write("VBS 'app.Hardcopy.PreferredFilename = \"%s.png\"' " % filename)
        # self.adapter.write("VBS? 'app.Hardcopy.Print' ")
    def save_screen_to_file(self, filename: str, path: str = "D:\\HardCopy\\"):
        """
        Speichert einen Screenshot des aktuellen Displays des LeCroy-Oszilloskops in einer Datei.
        Verwendet SCPI-Befehle, um das Bild zu speichern, ohne VBS oder `StoreHardcopyToFile`.
        
        :param filename: Der Name der zu speichernden Bilddatei (einschließlich der Dateiendung, z.B. 'screenshot.png').
        :param path: Der Pfad, an dem die Datei gespeichert wird (Standard ist 'D:\\HardCopy\\').
        """
        # Setzt das Zielverzeichnis und die Dateiname für den Screenshot
        cmd = f"DISK:PATH '{path}'"
        self.adapter.write(cmd)

        # Setzt den Dateinamen für den Screenshot
        cmd = f"DISK:FILE '{filename}'"
        self.adapter.write(cmd)

        # Befehl zum Speichern des Screenshots
        cmd = "SAVE:SCREEN"
        self.adapter.write(cmd)
    class Measurement(object):

        SOURCE_VALUES = ['C1', 'C2', 'C3', 'C4', 'F1', 'F2', 'F3', 'F4']

        def __init__(self, parent):
            self.parent = parent

        def amplitude(self, source):
            """Get signal amplitude"""
            if source in HDO.Measurement.SOURCE_VALUES:
                value = self.parent.ask("%s" % (source + ':PAVA? AMPL'))
            else:
                raise ValueError("Invalid source ('%s') provided to %s" % (
                    self.parent, source))
            return float(value.split(',')[1])

        def area(self, source):
            """Get signal integral"""
            if source in HDO.Measurement.SOURCE_VALUES:
                value = self.parent.ask("%s" % (source + ':PAVA? area'))
            else:
                raise ValueError("Invalid source ('%s') provided to %s" % (
                    self.parent, source))
            return float(value.split(',')[1])

        def cyclesnumber(self, source):
            """Get the number of signal cycle"""
            if source in HDO.Measurement.SOURCE_VALUES:
                value = self.parent.ask("%s" % (source + ':PAVA? CYCL'))
            else:
                raise ValueError("Invalid source ('%s') provided to %s" % (
                    self.parent, source))
            return float(value.split(',')[1])

        def falltime90to10(self, source):
            """Get fall time from 90% to 10% """
            if source in HDO.Measurement.SOURCE_VALUES:
                value = self.parent.ask("%s" % (source + ':PAVA? FALL'))
            else:
                raise ValueError("Invalid source ('%s') provided to %s" % (
                    self.parent, source))
            return float(value.split(',')[1])

        def frequency(self, source):
            """Get signal frequency"""
            if source in HDO.Measurement.SOURCE_VALUES:
                value = self.parent.ask("%s" % (source + ':PAVA? FREQ'))
            else:
                raise ValueError("Invalid source ('%s') provided to %s" % (
                    self.parent, source))
            return float(value.split(',')[1])

        def max(self, source):
            """Get signal maximimum"""
            if source in HDO.Measurement.SOURCE_VALUES:
                value = self.parent.ask("%s" % (source + ':PAVA? MAX'))
            else:
                raise ValueError("Invalid source ('%s') provided to %s" % (
                    self.parent, source))
            return float(value.split(',')[1])

        def mean(self, source):
            """Get signal mean"""
            if source in HDO.Measurement.SOURCE_VALUES:
                value = self.parent.ask("%s" % (source + ':PAVA? MEAN'))
            else:
                raise ValueError("Invalid source ('%s') provided to %s" % (
                    self.parent, source))
            return float(value.split(',')[1])

        def min(self, source):
            if source in HDO.Measurement.SOURCE_VALUES:
                value = self.parent.ask("%s" % (source + ':PAVA? MIN'))
            else:
                raise ValueError("Invalid source ('%s') provided to %s" % (
                    self.parent, source))
            return float(value.split(',')[1])

        def peak2peak(self, source):
            """Get signal peak to peak value"""
            if source in HDO.Measurement.SOURCE_VALUES:
                value = self.parent.ask("%s" % (source + ':PAVA? PKPK'))
            else:
                raise ValueError("Invalid source ('%s') provided to %s" % (
                    self.parent, source))
            return float(value.split(',')[1])

        def period(self, source):
            """Get signal period"""
            if source in HDO.Measurement.SOURCE_VALUES:
                value = self.parent.ask("%s" % (source + ':PAVA? PER'))
            else:
                raise ValueError("Invalid source ('%s') provided to %s" % (
                    self.parent, source))
            return float(value.split(',')[1])

        def risetime10to90(self, source):
            """Get rise time from 10% to 90% """
            if source in HDO.Measurement.SOURCE_VALUES:
                value = self.parent.ask("%s" % (source + ':PAVA? RISE'))
            else:
                raise ValueError("Invalid source ('%s') provided to %s" % (
                    self.parent, source))
            return float(value.split(',')[1])

        def rms(self, source):
            """Get signal RMS value"""
            if source in HDO.Measurement.SOURCE_VALUES:
                value = self.parent.ask("%s" % (source + ':PAVA? RMS'))
            else:
                raise ValueError("Invalid source ('%s') provided to %s" % (
                    self.parent, source))
            return float(value.split(',')[1])

        def std_dev(self, source):
            """Get signal stansard deviation"""
            if source in HDO.Measurement.SOURCE_VALUES:
                value = self.parent.ask("%s" % (source + ':PAVA? SDEV'))
            else:
                raise ValueError("Invalid source ('%s') provided to %s" % (
                    self.parent, source))
            return float(value.split(',')[1])

        def top(self, source):
            if source in HDO.Measurement.SOURCE_VALUES:
                value = self.parent.ask("%s" % (source + ':PAVA? TOP'))
            else:
                raise ValueError("Invalid source ('%s') provided to %s" % (
                    self.parent, source))
            return float(value.split(',')[1])

        def width(self, source):
            if source in HDO.Measurement.SOURCE_VALUES:
                value = self.parent.ask("%s" % (source + ':PAVA? WID'))
            else:
                raise ValueError("Invalid source ('%s') provided to %s" % (
                    self.parent, source))
            return float(value.split(',')[1])

        def width_neg(self, source):
            if source in HDO.Measurement.SOURCE_VALUES:
                value = self.parent.ask("%s" % (source + ':PAVA? widthn'))
            else:
                raise ValueError("Invalid source ('%s') provided to %s" % (
                    self.parent, source))
            return float(value.split(',')[1])

        def duty(self, source):
            if source in HDO.Measurement.SOURCE_VALUES:
                value = self.parent.ask("%s" % (source + ':PAVA? DUTY'))
            else:
                raise ValueError("Invalid source ('%s') provided to %s" % (
                    self.parent, source))
            return float(value.split(',')[1])

