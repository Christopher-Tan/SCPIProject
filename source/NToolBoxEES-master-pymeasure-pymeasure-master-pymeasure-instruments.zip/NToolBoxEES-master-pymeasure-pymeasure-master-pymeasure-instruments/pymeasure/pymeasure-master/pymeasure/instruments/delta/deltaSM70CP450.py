# Basic functions for Delta SM70-CP-450 bidirectional Power Supply
#
# Library adapted from example provided from Delta website (https://www.delta-elektronika.nl/products/sm15k-series)
# Code maybe working for complete "Delta SM15K - Series 15kW DC Power Supply", however, cannot be tested without device
#
# R.Scheuss, 01.04.2025
#
# Connected with LAN cable
#
# IMPORTANT: - To set new values for U/I/P the 'programming source' have to be set to 'eth' with: 'setProgSourceX()'
#            - The souce can be turned off at the panel even if it is in 'eth'-mode
#            - For get-commands the programming source is not relevant (works also if in 'front'-mode and so on)
#            - The programming souce can also be changed on the panel of the device: Menu->Configuration->Prg Source
#
# HOW TO USE: - see at the end of this file
#
from pymeasure.instruments import Instrument

class DeltaSM70CP450(Instrument):
    validSrcList = ["front", "web", "seq", "eth", "slot1", "slot2", "slot3", "slot4", "loc", "rem"]
   

    def __init__(self, adapter, **kwargs):
        super().__init__(adapter, "SM70CP450 DC Source/Load", **kwargs)

    def getDeviceIdent(self):
        return self.ask("*IDN?")
    
    # VOLTAGE COMMANDS ---------------------------------------------------------
    # get voltage at the terminals
    def getVoltage(self):
        return self.ask("MEAS:VOL?")  
    
    # get max voltage the source is capable of
    def getMaxVoltage(self):
        return self.ask("SOUR:VOLT:MAX?")

    def setVoltage(self, voltage):
        self.write("SOUR:VOLT " + str(voltage))

    # change the programming source to set voltage values, need to be 'eth' to set via this script!
    # possible settings: none, front, eth, web, seq, slot1, slot2, slot3, slot4
    def setProgSourceV(self, src):
        if src in DeltaSM70CP450.validSrcList:
            self.write("SYST:REM:CV " + src)
        else:
            raise Exception("Invalid source")


    # CURRENT COMMANDS ---------------------------------------------------------
    # get current at the terminals
    def getCurrent(self):
        return self.ask("MEAS:CUR?")  
    
    # get the max positive current the source is capable of
    def getMaxPosCurrent(self):
        return self.ask("SOUR:CUR:MAX?")

    # get the max negative current the source is capable of
    def getMaxNegCurrent(self):
        return self.ask("SOUR:CUR:NEG:MAX?")

    # set the positive current
    def setPosCurrent(self, current):
        self.write("SOUR:CUR " + str(current))

    # set the negative current
    def setNegCurrent(self, current):
        self.write("SOUR:CUR:NEG " + str(current))

    # change the programming source to set current values, need to be 'eth' to set via this script!
    # possible settings: none, front, eth, web, seq, slot1, slot2, slot3, slot4
    def setProgSourceI(self, src):
        if src in DeltaSM70CP450.validSrcList:
            self.write("SYST:REM:CC " + src)
        else:
            raise Exception("Invalid source")

    # POWER COMMANDS ---------------------------------------------------------
    # get power at the terminals
    def getPower(self):
        return self.ask("MEAS:POW?")  
    
    # get the max positive power the source is capable of
    def getMaxPosPower(self):
        return self.ask("SOUR:POW:MAX?")

    # get the max negative power the source is capable of
    def getMaxNegPower(self):
        return self.ask("SOUR:POW:NEG:MAX?")

    # set the positive power
    def setPosPower(self, current):
        self.write("SOUR:POW " + str(current))

    # set the negative power
    def setNegPower(self, current):
        self.write("SOUR:POW:NEG " + str(current))

    # change the programming source to set power values, need to be 'eth' to set via this script!
    # possible settings: none, front, eth, web, seq, slot1, slot2, slot3, slot4
    def setProgSourceP(self, src):
        if src in DeltaSM70CP450.validSrcList:
            self.write("SYST:REM:CP " + src)
        else:
            raise Exception("Invalid source")



    def enableOutput(self):
        self.write("OUTPUT 1")

    def disableOutput(self):
        self.write("OUTPUT 0")




if __name__=="__main__":

    myDelta = DeltaSM70CP450('TCPIP0::PSies018.ost.ch::8462::SOCKET', write_termination='\n', read_termination='\n')
    
    print("Device ID: " + myDelta.getDeviceIdent())


    # voltage command test -------------------------------------------
    print("Max Voltage = " + myDelta.getMaxVoltage())
    print("Voltage = " + myDelta.getVoltage())

    myDelta.setProgSourceV("eth")
    myDelta.setVoltage(6.2)
    

    # current command test -------------------------------------------
    print("Max Pos Current = " + myDelta.getMaxPosCurrent())
    print("Max Neg Current = " + myDelta.getMaxNegCurrent())
    print("Current = " + myDelta.getCurrent())


    myDelta.setProgSourceI("eth")
    myDelta.setPosCurrent(1.213)
    myDelta.setNegCurrent(-2.345)

    # power command test -------------------------------------------
    print("Max Pos Power = " + myDelta.getMaxPosPower())
    print("Max Neg Power = " + myDelta.getMaxNegPower())
    print("Power = " + myDelta.getPower())


    myDelta.setProgSourceP("eth")
    myDelta.setPosPower(100)
    myDelta.setNegPower(-120)

    myDelta.enableOutput()
    myDelta.disableOutput()

    # DOES NOT WORK!!!
    # If the device is not in 'eth' mode, new values cannot be set
    myDelta.setProgSourceV("front")
    myDelta.setVoltage(6.2)

    # set back to 'front' mode for the next user of the device which wants to control the source at the front panel
    myDelta.setProgSourceV("front")
    myDelta.setProgSourceI("front")
    myDelta.setProgSourceP("front")

    print("End")


