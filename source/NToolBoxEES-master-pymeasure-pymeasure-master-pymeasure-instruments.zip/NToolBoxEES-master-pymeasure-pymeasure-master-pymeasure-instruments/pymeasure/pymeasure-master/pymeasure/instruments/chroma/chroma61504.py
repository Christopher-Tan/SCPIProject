from pymeasure.instruments import Instrument
from time import sleep
import numpy as np


class Chroma61504(Instrument):
    """ Chroma61504 Programmable AC Source"""

    def __init__(self, adapter, **kwargs):
        super(Chroma61504, self).__init__(
            adapter, "Chroma61504 Programmable AC Source", **kwargs
        )

    def set_output(self,state="OFF"):
        """ ON enables the AC Source, OFF disables the AC Source """
        command = "OUTP "+state
        self.write(command)       
    def output_enable(self):
        self.write("OUTP ON")

    def output_disable(self):
        self.write("OUTP OFF")
 
    def set_voltage(self, acvoltage):
        """valid range: 0- 300 V"""
        command = "SOUR:VOLT:LEV:IMM:AMPL:AC "+str(acvoltage)
        self.write(command) 
    def set_rampvoltage(self, voltage, steps=25, duration=0.5):
        """ Ramps the voltage to a value in Volts by traversing a linear spacing
        of voltage steps over a duration, defined in seconds.
        :param steps: A number of linear steps to traverse
        :param duration: A time in seconds over which to ramp
        """
        start_voltage = self.output_voltage
        stop_voltage = voltage
        pause = duration/steps
        if start_voltage != stop_voltage:
            voltages = np.linspace(start_voltage, stop_voltage, steps)
            for voltage in voltages:
                self.set_voltage(voltage)
                sleep(pause)
        
    def set_frequency(self, freq):
        """valid range: 15 - 1000 Hz"""
        command = "SOUR:FREQ:IMM "+str(freq)
        self.write(command) 
    def set_voltagelimit(self,voltlimit,type="AC"):
        """AC - max AC voltage, DCMIN - minimal DC Voltage , DCMAX - max DC Voltage
        """
        if(type=="DCMIN"):
            command = "SOUR:VOLT:LIM:DC:MIN "+str(voltlimit)
        elif(type=="DCMAX"):
            command = "SOUR:VOLT:LIM:DC:PLUS "+str(voltlimit)
        else:
            command = "SOUR:VOLT:LIM:AC "+str(voltlimit)
        self.write(command)
    def set_currentlimit(self,currlimit):
        """max rms current limit"""
        command = "SOUR:CURR:LIM "+str(currlimit)
        self.write(command) 
    def get_frequency(self):
        """returns output frequency in Hz"""
        command = 'MEAS:SCAL:FREQ?'
        value = self.ask(command) 
        return value
    def get_voltage(self, type="ACDC"):
        """ACDC returns RMS voltage, DC returns DC voltage """
        command = 'MEAS:VOLT:'+ type+'?'
        value = self.ask(command) 
        return value
    def get_current(self, type="AC"):
        """AC returns RMS current, DC returns DC current, MAX returns the peak current, CRES returns the CREST factor, ratio of peak to rms current"""
        if (type=="AC" or type=="DC" or type=="CRES"):
            command = 'MEAS:CURR:'+ type+'?'
        else:
            command = 'MEAS:CURR:AMPL:'+ type+'?'
        value = self.ask(command) 
        return value
    def get_power(self, type="REAL"):
        """REAL returns the true power, APP returns the apparent power and REAC returns the reactive power"""
        command = 'MEAS:SCAL:POW:AC:'+type+'?'
        value = self.ask(command) 
        return value   
    def get_powerfactor(self):
        """returns power factor """
        command = 'MEAS:SCAL:POW:AC:PFAC?'
        value = self.ask(command) 
        return value
    def read_current(self):
        """Reads current from previously selected channel"""
        query = 'MEAS:SCAL:CURR?'
        value = self.instrument.query(query)
        return value

