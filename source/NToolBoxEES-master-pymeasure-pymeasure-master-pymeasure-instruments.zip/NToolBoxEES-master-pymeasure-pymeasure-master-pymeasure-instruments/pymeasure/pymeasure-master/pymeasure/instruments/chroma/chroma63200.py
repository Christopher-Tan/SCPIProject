# Basic functions for DC load Chroma 63200
#
# tested with Chroma 63204
# R.Scheuss, 04.11.2024
#
# Connected with a UC-232A USB-to-Serial Adcapter with a Null-Modem cable (Crossed RX/TX)

import serial



class Chroma63200():
    def __init__(self, port_str, baudrate=115200, bytesize=8, parity='N', stopbits=1, timeout=1.0):
        self.port = serial.Serial(port=port_str, baudrate=baudrate, bytesize=bytesize, parity=parity, stopbits=stopbits, timeout=timeout)

    # def open(self):
    #     # Configure the COM Port
    #     if not self.port.is_open:
    #         self.port.open()
    #     # self._serial = self.getSerialNumber()
    #     # self._fw = self.getFirmwareVersion()

    def close(self):
        self.port.close()

    def remoteControl(self):
        self.port.write("CONF:REM ON\n".encode('ascii'))

    def localControl(self):
        self.port.write("CONF:REM OFF\n".encode('ascii'))

    def reset(self):
        self.remoteControl()
        self.port.write("*RST\n".encode('ascii'))
        self.localControl()
    

    def getIdentification(self):
        self.remoteControl()
        self.port.write("*IDN?\n".encode('ascii'))
        ret = self.port.readline().decode('ascii')
        self.localControl()
        return ret
    
    def loadON(self):
        self.remoteControl()
        self.port.write("LOAD ON\n".encode('ascii'))
        self.localControl()

    def loadOFF(self):
        self.remoteControl()
        self.port.write("LOAD OFF\n".encode('ascii'))
        self.localControl()

    def setVoltageA(self, voltage):
        if voltage < 0:
            voltage = 0
        if voltage > 600:
            voltage = 600
        self.remoteControl()
        self.port.write("VOLT:L1 {0:.3f}\n".format(voltage).encode('ascii'))
        self.localControl()



    def setVoltageB(self, voltage):
        if voltage < 0:
            voltage = 0
        if voltage > 600:
            voltage = 600
        self.remoteControl()
        self.port.write("VOLT:L2 {0:.3f}\n".format(voltage).encode('ascii'))
        self.localControl()

    def getVoltageA(self):
        self.remoteControl()
        self.port.write("VOLT:L1?\n".encode('ascii'))
        ret = float(self.port.readline().decode('ascii'))
        self.localControl()
        return ret

    def getVoltageB(self):
        self.remoteControl()
        self.port.write("VOLT:L2?\n".encode('ascii'))
        ret = float(self.port.readline().decode('ascii'))
        self.localControl()
        return ret
        # return float(self.DCload.query("VOLT:L2?\n").rstrip('\n'))

    def setCurrentA(self, current):
        if current < 0:
            current = 0
        if current > 100:
            current = 100
        self.remoteControl()
        self.port.write('CURR:STAT:L1 {0:.3f}\n'.format(current).encode('ascii'))
        self.localControl()

    def setCurrentB(self, current):
        if current < 0:
            current = 0
        if current > 100:
            current = 100
        self.remoteControl()
        self.port.write('CURR:STAT:L2 {0:.3f}\n'.format(current).encode('ascii'))
        self.localControl()

    def getCurrentA(self):
        self.remoteControl()
        self.port.write("CURR:STAT:L1?\n".encode('ascii'))
        ret = float(self.port.readline().decode('ascii'))
        self.localControl()
        return ret
        # return float(self.DCload.query("CURR:STAT:L1?\n").rstrip('\n'))

    def getCurrentB(self):
        self.remoteControl()
        self.port.write("CURR:STAT:L2?\n".encode('ascii'))
        ret = float(self.port.readline().decode('ascii'))
        self.localControl()
        return ret
        # return float(self.DCload.query("CURR:STAT:L2?\n").rstrip('\n'))

    def activateA(self):
        self.remoteControl()
        self.port.write("CURR:STAT A\n".encode('ascii'))
        self.localControl()

    def activateB(self):
        self.remoteControl()
        self.port.write("CURR:STAT B\n".encode('ascii'))
        self.localControl()

    def setMode(self, mode):
        # Modes
            # CCL       low constant current, 0 - 10A
            # CCH       high constant current, 0 - 100A
            # CVL       low constant voltage, 0 - 150V
            # CVH       high constant voltage, 0 - 600V
        self.remoteControl()
        self.port.write(("MODE " + mode + "\n").encode('ascii'))
        self.localControl()

    def getMode(self):
        self.remoteControl()
        self.port.write("Mode?\n".encode('ascii'))
        mode = self.port.readline().decode('ascii')
        self.localControl()
        # mode = self.DCload.query("Mode?\n")
        if mode == "0\n":
            return "CC low"
        elif mode == "1\n":
            return "CC high"
        elif mode == "6\n":
            return "CV low"
        elif mode == "7\n":
            return "CV high"
        else:
            return "undef"



if __name__=="__main__":
    print("Main\n")

    myDCLoad = Chroma63200('COM4', baudrate=115200, bytesize=8, parity='N', stopbits=1, timeout=1.0)
    
    myDCLoad.reset()

    ID = myDCLoad.getIdentification()
    print(ID)

    myDCLoad.loadON()
    myDCLoad.loadOFF()

    myDCLoad.setMode("CCL")
    
    print(myDCLoad.getMode())

    myDCLoad.setCurrentA(9.7)

    myDCLoad.setCurrentB(5.5)

    myDCLoad.setCurrentA(2.123456)
    ret = myDCLoad.getCurrentA()
    print(ret) 
    print(type(ret))

    myDCLoad.setCurrentB(3.6598)
    print(myDCLoad.getCurrentB()) 

    myDCLoad.activateA()
    myDCLoad.activateB()
    myDCLoad.activateA()

    myDCLoad.setMode("CVH")
    print(myDCLoad.getMode()) 

    myDCLoad.setVoltageA(555.9554564)

    myDCLoad.setVoltageB(566.255666)

    print(myDCLoad.getVoltageA())
    print(myDCLoad.getVoltageB())

    myDCLoad.close()
