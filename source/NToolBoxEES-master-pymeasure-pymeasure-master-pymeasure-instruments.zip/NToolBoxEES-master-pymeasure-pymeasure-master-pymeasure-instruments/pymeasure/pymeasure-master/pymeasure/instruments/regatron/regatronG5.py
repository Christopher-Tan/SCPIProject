from pymeasure.instruments import Instrument
import time

class RegatronG5(Instrument):
    def __init__(self, adapter, delay=0.05, **kwargs):
        super(RegatronG5, self).__init__(
            adapter, "Regatron G5", **kwargs)

    # VOLTage commands
    def getVoltageLow(self):
        """Returns the lower limit of output voltage in volts."""
        return self.ask("SOURce:REFerence:VOLTage:LEVel:IMMediate:LOW?")
    
    def setVoltageLow(self, voltage):
        """Sets the lower limit of output voltage. Accepts a value in volts, 'MINimum', or 'MAXimum'."""
        self.write(f"SOURce:REFerence:VOLTage:LEVel:IMMediate:LOW {voltage}")
        time.sleep(0.1)

    def getVoltageRef(self):
        """Returns the reference value of output voltage in volts."""
        return self.ask("SOURce:REFerence:VOLTage:LEVel:IMMediate:AMPLitude?")
    
    def setVoltageRef(self, voltage):
        """Sets the reference value of output voltage. Accepts a value in volts, 'MINimum', or 'MAXimum'."""
        self.write(f"SOURce:REFerence:VOLTage:LEVel:IMMediate:AMPLitude {voltage}")
        time.sleep(0.1)
    def getVoltageHigh(self):
        """Returns the upper limit of output voltage in volts."""
        return self.ask("SOURce:REFerence:VOLTage:LEVel:IMMediate:HIGH?")
    
    def setVoltageHigh(self, voltage):
        """Sets the upper limit of output voltage. Accepts a value in volts, 'MINimum', or 'MAXimum'."""
        self.write(f"SOURce:REFerence:VOLTage:LEVel:IMMediate:HIGH {voltage}")
        time.sleep(0.1)
    # CURRent commands
    def getCurrentLow(self):
        """Returns the lower limit of output current in amperes."""
        return self.ask("SOURce:REFerence:CURRent:LEVel:IMMediate:LOW?")
    
    def setCurrentLow(self, current):
        """Sets the lower limit of output current. Accepts a value in amperes, 'MINimum', or 'MAXimum'."""
        self.write(f"SOURce:REFerence:CURRent:LEVel:IMMediate:LOW {current}")
        time.sleep(0.1)
    def getCurrentRef(self):
        """Returns the reference value of output current in amperes."""
        return self.ask("SOURce:REFerence:CURRent:LEVel:IMMediate:AMPLitude?")
    
    def setCurrentRef(self, current):
        """Sets the reference value of output current. Accepts a value in amperes, 'MINimum', or 'MAXimum'."""
        self.write(f"SOURce:REFerence:CURRent:LEVel:IMMediate:AMPLitude {current}")
        time.sleep(0.1)
    def getCurrentHigh(self):
        """Returns the upper limit of output current in amperes."""
        return self.ask("SOURce:REFerence:CURRent:LEVel:IMMediate:HIGH?")
    
    def setCurrentHigh(self, current):
        """Sets the upper limit of output current. Accepts a value in amperes, 'MINimum', or 'MAXimum'."""
        self.write(f"SOURce:REFerence:CURRent:LEVel:IMMediate:HIGH {current}")
        time.sleep(0.1)
    # POWer commands
    def getPowerLow(self):
        """Returns the lower limit of output power in watts."""
        return self.ask("SOURce:REFerence:POWer:LEVel:IMMediate:LOW?")
    
    def setPowerLow(self, power):
        """Sets the lower limit of output power. Accepts a value in watts, 'MINimum', or 'MAXimum'."""
        self.write(f"SOURce:REFerence:POWer:LEVel:IMMediate:LOW {power}")
        time.sleep(0.1)
    def getPowerRef(self):
        """Returns the reference value of output power in watts."""
        return self.ask("SOURce:REFerence:POWer:LEVel:IMMediate:AMPLitude?")
    
    def setPowerRef(self, power):
        """Sets the reference value of output power. Accepts a value in watts, 'MINimum', or 'MAXimum'."""
        self.write(f"SOURce:REFerence:POWer:LEVel:IMMediate:AMPLitude {power}")
        time.sleep(0.1)
    def getPowerHigh(self):
        """Returns the upper limit of output power in watts."""
        return self.ask("SOURce:REFerence:POWer:LEVel:IMMediate:HIGH?")
    
    def setPowerHigh(self, power):
        """Sets the upper limit of output power. Accepts a value in watts, 'MINimum', or 'MAXimum'."""
        self.write(f"SOURce:REFerence:POWer:LEVel:IMMediate:HIGH {power}")
        time.sleep(0.1)
    # INTernalRESistance commands
    def getInternalResistanceRef(self):
        """Returns the reference value of internal resistance in ohms."""
        return self.ask("SOURce:REFerence:INTernalRESistance:LEVel:IMMediate:AMPLitude?")
    
    def setInternalResistanceRef(self, resistance):
        """Sets the reference value of internal resistance. Accepts a value in ohms, 'MINimum', or 'MAXimum'."""
        self.write(f"SOURce:REFerence:INTernalRESistance:LEVel:IMMediate:AMPLitude {resistance}")
        time.sleep(0.1)
    # COntrollerMODE commands
    #ControllerMode { VoltageControlled = 1 , CurrentControlled = 2 , PowerControlled = 3 , ResistanceControlled = 4 }
    def getControllerMode(self):
        """Returns the actual controller mode."""
        return self.ask("SOUR:REF:COMODE?")
    
    def setControllerMode(self, mode):
        """Sets the actual controller mode. Accepts 'VOLTage', 'CURRent', 'POWer', 'LOADRESistance', or corresponding numbers 1, 2, 3, 4."""
        self.write(f"SOUR:REF:COMODE {mode}")
        time.sleep(0.1)
    # SLOPe commands
    def getVoltageSlopeGradient(self):
        """Returns the actual set voltage slope in volts per millisecond."""
        return self.ask("SOURce:REFerence:VOLTage:SLOPe:GRAdient?")
    
    def setVoltageSlopeGradient(self, slope):
        """Sets the voltage slope. Accepts a value in volts per millisecond."""
        self.write(f"SOURce:REFerence:VOLTage:SLOPe:GRAdient {slope}")
        time.sleep(0.1)
    def getCurrentSlopeGradient(self):
        """Returns the actual set current slope in amperes per millisecond."""
        return self.ask("SOURce:REFerence:CURRent:SLOPe:GRAdient?")
    
    def setCurrentSlopeGradient(self, slope):
        """Sets the current slope. Accepts a value in amperes per millisecond."""
        self.write(f"SOURce:REFerence:CURRent:SLOPe:GRAdient {slope}")
        time.sleep(0.1)
    def getPowerSlopeGradient(self):
        """Returns the actual set power slope in watts per millisecond."""
        return self.ask("SOURce:REFerence:POWer:SLOPe:GRAdient?")
    
    def setPowerSlopeGradient(self, slope):
        """Sets the power slope. Accepts a value in watts per millisecond."""
        self.write(f"SOURce:REFerence:POWer:SLOPe:GRAdient {slope}")
        time.sleep(0.1)
    def getVoltageSlopeEnable(self):
        """Returns whether the voltage slope is enabled (1) or disabled (0)."""
        return self.ask("SOURce:REFerence:VOLTage:SLOPe:ENABle?")
    
    def setVoltageSlopeEnable(self, state):
        """Enables (1) or disables (0) the voltage slope."""
        self.write(f"SOURce:REFerence:VOLTage:SLOPe:ENABle {state}")
        time.sleep(0.1)
    def getCurrentSlopeEnable(self):
        """Returns whether the current slope is enabled (1) or disabled (0)."""
        return self.ask("SOURce:REFerence:CURRent:SLOPe:ENABle?")
    
    def setCurrentSlopeEnable(self, state):
        """Enables (1) or disables (0) the current slope."""
        self.write(f"SOURce:REFerence:CURRent:SLOPe:ENABle {state}")
        time.sleep(0.1)
    def getPowerSlopeEnable(self):
        """Returns whether the power slope is enabled (1) or disabled (0)."""
        return self.ask("SOURce:REFerence:POWer:SLOPe:ENABle")
    
    # Output State Commands
    def getOutputState(self):
        """Returns the current state of the output.
        
        0 = Output is switched off.
        1 = Output is switched on.
        """
        return self.ask("OUTPut:STATe?")
    
    def setOutputState(self, state):
        """Sets the state of the output.
        - 'ON' or 1 to switch the output on.
        - 'OFF' or 0 to switch the output off.
        """
        if state in ["ON", "OFF", 1, 0]:
            self.write(f"OUTPut:STATe {state}")
            time.sleep(0.1)
        else:
            raise ValueError("Invalid state. Use 'ON', 'OFF', 1, or 0.")
        
    def ON (self):
        self.setOutputState('ON')
    def OFF (self):
        self.setOutputState('OFF')        
    def setCurrentLimits(self, negLim, posLim):
        self.setCurrentLow(negLim)
        self.setCurrentHigh(posLim)
    def setVoltageLimits(self, negLim, posLim):
        self.setVoltageLow(negLim)
        self.setVoltageHigh(posLim)
    def setPowerLimits(self, negLim, posLim):
        self.setPowerLow(negLim)
        self.setPowerHigh(posLim)
    
    def saveSettings(self):
        """Speichert die aktuellen Einstellungen im nichtflüchtigen Speicher."""
        self.write('*SAV 0')
        time.sleep(0.1)
    def loadSettings(self):
        """Lädt die gespeicherten Einstellungen aus dem nichtflüchtigen Speicher."""
        self.write('*RCL')

    def getError(self):
        """Liest den nächsten Fehler aus der Fehlerwarteschlange."""
        return self.ask('SYSTem:ERRor:NEXT?')
    
    def getAllErrors(self):
        """Liest alle Fehler aus der Fehlerwarteschlange."""
        return self.ask('SYSTem:ERRor:ALL?')
    
    def operationComplete(self):
        """Fragt ab, ob alle vorherigen Operationen abgeschlossen sind."""
        return self.ask('*OPC?')