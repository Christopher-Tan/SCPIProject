# -*- coding: utf-8 -*-
"""
Created on Thu Nov 18 10:22:14 2021

@author: JBU
"""
import clr   #Imports the pythonnet to use .Net functionality in python.
import os

dll_dir = os.path.dirname(os.path.abspath(__file__))
dll_path = os.path.join(dll_dir, 'Regatron.G5.Api')
clr.AddReference(dll_path) #Adds the Regatron.G5.Api assembly. The Regatron.G5.Api.dll and Regatron.G5.FunctionGeneratorNative.dll has to be placed right next to this script.

from Regatron.G5.Api import G5ApiException
from Regatron.G5.Api.System import G5System
from Regatron.G5.Common import FunctionGeneratorTriggerMode
from Regatron.G5.Common import FunctionGeneratorFunctionType
from Regatron.G5.Common import FunctionGeneratorPhysicalQuantity
from Regatron.G5.Common import FunctionGeneratorSequenceFinishBehaviour
from Regatron.G5.Common import FunctionGeneratorCommand
from Regatron.G5.Common import ControllerMode

g5Instance = G5System.Instance #Gets the G5System-instance which is the entry point for everything.

class RegatronG5API():
    def __init__(self, ip_str):            
        self.ip = ip_str
        self.port = 2000
        self.SN = None
        self.name = None
        self.fw = None
        self.FPGAfw = None
        self.state = None
        self.warnings = None
        self.errors = None

    #Connect to a device if not yet a connection is established.
    def connect(self):
        # Configure the COM Port
        if not g5Instance.IsConnected():
             g5Instance.Connect(self.ip, self.port)
             if g5Instance.IsConnected():
                self.SN = g5Instance.GetConnectedDevice().GetInformation().GetSerialNumber()
                self.name =  g5Instance.GetConnectedDevice().GetInformation().GetDeviceName()
                self.state = g5Instance.GetConnectedDevice().GetState().GetState()
                self.errors =  g5Instance.GetConnectedDevice().GetState().HasErrors()
                self.warnings = g5Instance.GetConnectedDevice().GetState().HasWarnings()
        else:
            print("A device is already connected.")

     #ControllerMode { VoltageControlled = 1 , CurrentControlled = 2 , PowerControlled = 3 , ResistanceControlled = 4 }
    def setName(self, name):
         if g5Instance.IsConnected():
                g5Instance.GetConnectedDevice().GetInformation().SetDeviceName(name)
    def disconnect(self):
            g5Instance.Disconnect()
    def clearErrors(self):
        """
        This function resets the actual error state.
        """
        g5Instance.GetCommands().ClearErrors()
    def ON(self):
        """
        Switches ON the power output stage.    
        """   
        if g5Instance.IsConnected():
            try:
                result = True
                errorMessage = ""
                g5Instance.GetCommands().SetVoltageOn()
            except G5ApiException as exception:
                result = False
                errorMessage = exception.Message
        else:  
            result = False
            errorMessage = "No device connected."
        return result, errorMessage
         
    def OFF(self):
        """
        Switches OFF the power output stage.    
        """
        if g5Instance.IsConnected():
            try:
                result = True
                errorMessage = ""
                g5Instance.GetCommands().SetVoltageOff()
            except G5ApiException as exception:
                result = False
                errorMessage = exception.Message
        else:  
            result = False
            errorMessage = "No device connected."
        return result, errorMessage

    def setVoltage(self, value):
        if g5Instance.IsConnected():
            try:
                result = True
                errorMessage = ""
                g5Instance.GetReferenceValues().SetVoltage(value)
            except G5ApiException as exception:
                result = False
                errorMessage = exception.Message
        else:  
            result = False
            errorMessage = "No device connected."
        return result, errorMessage
    def setCurrent(self, value):
        if g5Instance.IsConnected():
            try:
                result = True
                errorMessage = ""
                g5Instance.GetReferenceValues().SetCurrent(value)
            except G5ApiException as exception:
                result = False
                errorMessage = exception.Message
        else:  
            result = False
            errorMessage = "No device connected."
        return result, errorMessage
    
    def setCurrentLimits(self, negLim, posLim):
        if g5Instance.IsConnected():
            try:
                result = True
                errorMessage = ""
                g5Instance.GetReferenceValues().SetMinimumCurrent(negLim)
                g5Instance.GetReferenceValues().SetMaximumCurrent(posLim)    
            except G5ApiException as exception:
                result = False
                errorMessage = exception.Message
        else:  
            result = False
            errorMessage = "No device connected."
        return result, errorMessage
    def setVoltageLimits(self, negLim, posLim):
        if g5Instance.IsConnected():
            try:
                result = True
                errorMessage = ""
                g5Instance.GetReferenceValues().SetMinimumVoltage(negLim)
                g5Instance.GetReferenceValues().SetMaximumVoltage(posLim)    
            except G5ApiException as exception:
                result = False
                errorMessage = exception.Message
        else:  
            result = False
            errorMessage = "No device connected."
        return result, errorMessage
    def setPowerLimits(self, negLim, posLim):
        if g5Instance.IsConnected():
            try:
                result = True
                errorMessage = ""
                g5Instance.GetReferenceValues().SetMinimumPower(negLim)
                g5Instance.GetReferenceValues().SetMaximumPower(posLim)    
            except G5ApiException as exception:
                result = False
                errorMessage = exception.Message
        else:  
            result = False
            errorMessage = "No device connected."
        return result, errorMessage

    def setControllerMode(self, mode):
        """
        Set controller mode
        CV: Constant Voltage Controlled
        CC: Constant Current Controlled
        CP: Constant Power Controlled
        CR: Constant Resistor Controlled
        """       
        if (mode=='CV'):
            g5Instance.GetReferenceValues().SetControllerMode(ControllerMode.VoltageControlled)
        elif (mode=='CC'):
            g5Instance.GetReferenceValues().SetControllerMode(ControllerMode.CurrentControlled)
        elif (mode=='CP'):
            g5Instance.GetReferenceValues().SetControllerMode(ControllerMode.PowerControlled)
        elif (mode=='CR'):
            g5Instance.GetReferenceValues().SetControllerMode(ControllerMode.ResistanceControlled)

    def getSystemState():
        if g5Instance.IsConnected():
            print("SN: " + str(g5Instance.GetConnectedDevice().GetInformation().GetSerialNumber()))
            print("Device name: " + g5Instance.GetConnectedDevice().GetInformation().GetDeviceName())
            print("Device state: " + str(g5Instance.GetConnectedDevice().GetState().GetState()))
            print("Device has errors: " + str(g5Instance.GetConnectedDevice().GetState().HasErrors()))
            print("Device has warnings: " + str(g5Instance.GetConnectedDevice().GetState().HasWarnings()))
        else:  
            print("No device connected.")
    # def getCommands(self):
    #     if g5Instance.IsConnected():
    #         commands=g5Instance.GetCommands()
    #         print("commands: " + commands)
    #     else:
    #         print("No device connected.")  

    #Gets the actual values vor voltage, current and power.
    def getActualValues(self): 
        if g5Instance.IsConnected():
            actualSystemValuesInstance = g5Instance.GetActualValues()
            print("voltage: " + str(actualSystemValuesInstance.GetOutputVoltage()) + "\ncurrent: " + str(actualSystemValuesInstance.GetOutputCurrent()) + "\npower: " + str(actualSystemValuesInstance.GetOutputPower()))
        else:
            print("No device connected.")
    
   
    def getVoltage(self, value):
        """
        This function returns the value of the voltage , hence the
        limit where the controller switches to voltage control mode. 
        
        Returns the value of the reference voltage [V]
        """ 
        g5Instance.GetReferenceValues().GetVoltage()

    def getPower(self, value):
        """
        This function returns the value of the power.

        Returns the value of the power to be output [W]
        """ 
        g5Instance.GetReferenceValues().GetPower()



    #Sets the reference values for voltage, the upper limit for current and power and sets the device to voltage controlled.
    def setReferenceValues(self, voltageReference, currentUpperLimit, powerUpperLimit):
        if g5Instance.IsConnected():
            result = True
            errorMessage = ""
            try:
                referenceValuesInstance = g5Instance.GetReferenceValues().SetControllerMode(ControllerMode.VoltageControlled)
                referenceValuesInstance.SetControllerMode(ControllerMode.VoltageControlled)
                referenceValuesInstance.SetVoltage(float(voltageReference))
                referenceValuesInstance.SetMaximumCurrent(float(currentUpperLimit))
                referenceValuesInstance.SetMaximumPower(float(powerUpperLimit))
                print("voltage: " + str(referenceValuesInstance.GetVoltage()) + "\ncurrent: " + str(referenceValuesInstance.GetMaximumCurrent()) + "\npower: " + str(referenceValuesInstance.GetMaximumPower()))
            except G5ApiException as exception:
                result = False
                errorMessage = exception.Message
        else:
            errorMessage = "No device connected."
            result = False
        return result, errorMessage
    
    #Sets the function generator block.
    def setFunctionGeneratorBlock(self, physicalPreset, function, peakValue, offset, frequency, symmetry, functionRepetitions):
        if g5Instance.IsConnected():
            result = True
            errorMessage = ""
            try:
                functionGeneratorBlockConfigurationInstance = g5Instance.GetFunctionGenerator().GetFunctionGeneratorBlockConfiguration()
                functionGeneratorBlockConfigurationInstance.SetControlMode(physicalPreset)
                functionGeneratorBlockConfigurationInstance.SetBaseFunction(function)
                functionGeneratorBlockConfigurationInstance.SetPeakValue(float(peakValue))
                functionGeneratorBlockConfigurationInstance.SetOffset(float(offset))
                functionGeneratorBlockConfigurationInstance.SetFrequency(float(frequency))
                functionGeneratorBlockConfigurationInstance.SetSymmetry(float(symmetry))
                functionGeneratorBlockConfigurationInstance.SetBaseFunctionRepetitions(functionRepetitions)
            except G5ApiException as exception:
                result = False
                errorMessage = exception.Message
        else:  
            result = False
            errorMessage = "No device connected."
        return result, errorMessage
        
    #Sets the function generator sequence.
    def setFunctionGeneratorSequence(self, triggerMode, behaviourWhenFinished, blockRepetitions, delay):
        if g5Instance.IsConnected():
            result = True
            errorMessage = ""
            try:
                functionGeneratorSequenceConfigurationInstance = g5Instance.GetFunctionGenerator().GetFunctionGeneratorSequenceConfiguration()
                functionGeneratorSequenceConfigurationInstance.SetTriggerMode(triggerMode)
                functionGeneratorSequenceConfigurationInstance.SetSequenceFinishBehaviour(behaviourWhenFinished)
                functionGeneratorSequenceConfigurationInstance.SetBlockRepetitions(blockRepetitions)
                functionGeneratorSequenceConfigurationInstance.SetDelayBetweenBlockRepetitions(float(delay))
            except G5ApiException as exception:
                result = False
                errorMessage = exception.Message
        else:
            result = False
            errorMessage = "No device connected."
        return result, errorMessage

    #Gets some system information.
    def getSystemState(self):
        if g5Instance.IsConnected():
            print("SN: " + str(g5Instance.GetConnectedDevice().GetInformation().GetSerialNumber()))
            print("Device name: " + g5Instance.GetConnectedDevice().GetInformation().GetDeviceName())
            print("Device state: " + str(g5Instance.GetConnectedDevice().GetState().GetState()))
            print("Device has errors: " + str(g5Instance.GetConnectedDevice().GetState().HasErrors()))
            print("Device has warnings: " + str(g5Instance.GetConnectedDevice().GetState().HasWarnings()))
        else:  
            print("No device connected.")
        
    #Gets the actual incidents.
    def getActualIncidents(self):
        if g5Instance.IsConnected():
            print("Device has errors: " + str(g5Instance.GetConnectedDevice().GetState().HasErrors()))
            listOfIncidents = g5Instance.GetConnectedDevice().GetState().GetIncidents()
            for incident in listOfIncidents:
                print("Incident code: " + str(incident.Code))
                print("Incident group: " + str(incident.Group))
                print("Incident type: " + str(incident.Type))
                print("Incident time stamp: " + str(incident.TimeStamp))
        else:  
            print("No device connected.")

           

        
    #Invokes the function generator commands.
    def setFunctionGeneratorCommand(self, functionGeneratorCommand):
        if g5Instance.IsConnected():
            try:
                result = True
                errorMessage = ""
                g5Instance.GetFunctionGenerator().SetCommand(functionGeneratorCommand)
            except G5ApiException as exception:
                result = False
                errorMessage = exception.Message
        else:  
            result = False
            errorMessage = "No device connected."
        return result, errorMessage
                        
