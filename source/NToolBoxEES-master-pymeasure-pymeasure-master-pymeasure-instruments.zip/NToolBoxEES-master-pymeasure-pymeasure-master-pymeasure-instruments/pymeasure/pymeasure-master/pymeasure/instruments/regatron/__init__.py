from .regatronGSS import RegatronGSS
from .regatronG5 import RegatronG5