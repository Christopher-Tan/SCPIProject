# Basic functions for ITECH 6015B Regenerative DC Electronic Load
#
# R.Scheuss, 01.01.2023
#
# Connected with LAN cable


# IMPORTANT:
# after each command, device is set back to local mode otherwise it is not possible to turn off source/load at device pannel!!!


# USAGE:
# choose between sink/source-mode or load-mode

# sink/source-mode:
#   - set mode with: setMode("SOURCE/SINK")
#   - set positive (source) current: setSourcePosCurrent(xx)
#   - set negative (sink) current: setSourceNegCurrent(xx)
#   - set voltage: setVoltage(xx)

# load-mode:
#   - set mode with: setMode("LOAD")
#   - set load current: getCurrentSetting())


from pymeasure.instruments import Instrument

class ITECH6018B(Instrument):
    """
    ITECH6018B DC Load/Source
    """
    
# Methods for SOURCE/SINK-mode AND LOAD-mode ==========================================================

    def __init__(self, adapter, **kwargs):
        super().__init__(adapter, "ITECH6018B DC Source/Load", **kwargs)
        
   
    def getDeviceIdent(self):
        """ get the device identification
        """
        return self.ask("*IDN?")

    def beep(self):
        """ the device will beep
        """
        self.write("SYST:BEEP:IMM")

    def getError(self):
        """ get device errors
        """
        return self.ask("SYST:ERR?")

    def remoteControl(self):
        """ set device to remote control mode
            - if not in remote mode, only reading is possible
            - "Execution error" if not set to remote mode
            """
        self.write("SYST:REM")

    def localControl(self):
        """ set devide into local control mode
            - buttons on device work only in local mode
            - turn off source/load on panel is only in local mode possible!!!"""
        self.write("SYST:LOC")

    def clearError(self):
        """ clears device errors
        """
        self.write("SYST:CLE")

    def setMode(self, mode="LOAD"):
        """ change device mode between load and source/sink
        :param mode: "SOURCE/SINK" or "LOAD"
        """
        self.remoteControl()
        if mode == "SOURCE/SINK":
            self.write("SYST:FUNC SOUR")

        elif mode == "LOAD":
            self.write("SYST:FUNC LOAD")

        else:
            print("invalid mode")
        self.localControl()


    def setCurrent(self, current):
        """ set the output current
            -In source/sink mode I+
            -In load mode Is
        :param current: [A] output current
        """
        self.remoteControl()
        self.write("CURR " + str(current))
        self.localControl()


    def getCurrentSetting(self):
        """ get current setting
            -In source/sink mode I+
            -In load mode Is
        """
        return self.ask("CURR?")




# =============================================================================================



# Methods for SOURCE/SINK-mode only ==================================================================

    def setVoltage(self, voltage):
        """ set the output voltage in source/sink mode
        :param voltage: [V] output voltage
        """
        self.remoteControl()
        self.write("VOLT " + str(voltage))
        self.localControl()


    def getVoltageSetting(self):
        """ get voltage setting
        """
        return self.ask("VOLT?")


    
    def getSourcePosCurrent(self):
        """ get positive current setting of source/sink mode
            - value I+
            - error "invalid command" if in load mode
        """
        return self.ask("CURR:LIM:POS?")

    def getSourceNegCurrent(self):
        """ get negative current setting of source/sink mode
            - value I-
            - error "invalid command" if in load mode
        """
        return self.ask("CURR:LIM:NEG?")

    def setSourcePosCurrent(self, current):
        """ set positive output current setting in source/sink mode
            - error "invalid command" if in load mode

        :param current: [A] output current limit I+
        """
        self.remoteControl()
        self.write("CURR:LIM:POS " + str(current))
        self.localControl()


    def setSourceNegCurrent(self, current):
        """ set negative output current setting in source/sink mode
            - error "invalid command" if in load mode

        :param current: [A] output current limit I-
        """
        self.remoteControl()
        self.write("CURR:LIM:NEG " + str(current))
        self.localControl()


    
    def getOutputStateSS(self):
        """ get the state of the output in SOURCE/SINK-mode, 0=OFF, 1=ON
        """
        return self.ask("OUTP?")

    def setOutputSS(self, state):
        """ enable/disable the output in SOURCE/SINK-mode
        :param state: "ON" or "OFF" 
        """
        self.remoteControl()
        if state == "ON":
            self.write("OUTP 1")
        elif state == "OFF":
            self.write("OUTP 0")
        else:
            print("invalid state")
        self.localControl()



    def setPriorityMode(self, prio):
        """ set the working mode of the power supply

        :param prio:    'VOLT' Indicates that the power supply is operating in CV priority mode
                        'CURR' Indicates that the power supply is operating in CC priority mode
        """
        self.remoteControl()
        if prio == "VOLT":
            self.write("FUNC VOLT")
        elif prio == "CURR":
            self.write("FUNC CURR")
        else:
            print("invalid prio")
        self.localControl()
# =============================================================================================


# Methods for LOAD-mode only ==================================================================
    def setOutputLoad(self, state):
        """ enable/disable the output in load mode
        :param state: "ON" or "OFF" 
        """
        self.remoteControl()
        if state == "ON":
            self.write("INP 1")
        elif state == "OFF":
            self.write("INP 0")
        else:
            print("invalid state")
        self.localControl()
# =============================================================================================


