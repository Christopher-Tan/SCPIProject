from pymeasure.instruments import Instrument
import numpy as np
import time

class Wt1806E(Instrument):
    """
    Represent the Yokogawa Power analyzer WT1806E
    """
    
    def __init__(self, adapter, delay=0.02, **kwargs):
        super(Wt1806E, self).__init__(
            adapter, "Power analyzer WT1806E", **kwargs
        )
        
    def getVolt(self, ch=1):
        """Misst die Spannung an einem bestimmten Kanal"""
        return self.ask(f'MEAS:VOLT:DC? (@{ch})')

    def getCurr(self, ch=1):
        """Misst den Strom an einem bestimmten Kanal"""
        return self.ask(f'MEAS:CURR:DC? (@{ch})')

    def getPower(self, ch=1):
        """Misst die Leistung an einem bestimmten Kanal"""
        return self.ask(f'MEAS:POW:DC? (@{ch})')

    def setVoltRange(self, chs=None, auto=False):
        """
        Konfiguriert den Spannungsbereich für mehrere Kanäle.
        :param chs: Liste von Spannungsbereichswerten für die Kanäle. 
        :param auto: Wenn True, wird der Spannungsbereich im Betrieb automatisch angepasst.
        """
        if chs is not None:
            cmd = f':INPUT:VOLTAGE:CONFIG:ALL ' + ','.join(map(str, chs))
        else:
            cmd = f':INPUT:VOLTAGE:CONFIG:ALL ALL'
        self.write(cmd)
        if auto:
            self.write(':INPUT:VOLTAGE:AUTO:ALL ON')
        else:
            self.write(':INPUT:VOLTAGE:AUTO:ALL OFF')
    def setCurrRange(self, chs=None, auto=False):
        """
        Konfiguriert den Strombereich für mehrere Kanäle.
        :param chs: Liste von Strombereichswerten für die Kanäle.
        :param auto: Wenn True, wird der Strombereich im Betrieb automatisch angepasst.
        """
        if auto:
            self.write(':INPUT:CURRENT:AUTO:ALL ON')
        else:
            self.write(':INPUT:VOLTAGE:AUTO:ALL OFF') 
        if chs is not None:
                cmd = f':INPUT:CURRENT:CONFIG:ALL ' + ','.join(map(str, chs))
                self.write(cmd)

    def enableRemote(self):
        """Aktiviert den Remote-Kommunikationsmodus"""
        self.write(':COMM:REM ON')
        time.sleep(1)

    def disableRemote(self):
        """Deaktiviert den Remote-Kommunikationsmodus"""
        self.write(':COMM:REM OFF')
   
    def isRemoteEnabled(self):
        """Überprüft, ob der Remote-Kommunikationsmodus aktiviert ist"""
        response = self.ask(':COMM:REM?')
        return response.strip() == '1'
    
    def setPllSource(self, source='U2'):
        """Setzt die PLL-Quelle für die Oberschwingungsmessung"""
        self.write(f':HARMONICS:PLLSOURCE {source}')

    def setNumericFormat(self, preset=1, number=64, fmt='ASCII'):
        """Richtet das numerische Format ein"""
        self.write(f':NUMERIC:NORMAL:PRESET {preset}')
        self.write(f':NUMERIC:NORMAL:NUMBER {number}')
        self.write(f':NUMERIC:FORMAT {fmt}')


    def setScalingFactor(self, elem, factor):
        """Setzt den Skalierungsfaktor für ein bestimmtes Element"""    
        self.write(f':SCAL:CT:ELEM{elem} {factor}')

    def setRate(self, rate='500MS'):
        """Setzt die Messrate"""
        self.write(f':RATE {rate}')
    
    def initMeasurement(self):
        """Initialisiert die Messung"""
        self.write(':NUM:LIST:CLE ALL')
    
    def binary_values(self, command, header_bytes=0, dtype=np.float32):
        """Hilfsmethode zum Abrufen binärer Werte"""
        raw_data = self.ask(command)
        return np.fromstring(raw_data[header_bytes:], dtype=dtype)

    def checkDataReady(self):
        """Überprüft, ob das Gerät bereit ist, Daten abzurufen"""
        response = self.ask('*OPC?')
        return response.strip() == '1'

    def waitForDataReady(self, timeout=10, interval=0.5):
        """
        Wartet, bis das Gerät bereit ist, Daten abzurufen.
        :param timeout: Maximale Wartezeit in Sekunden.
        :param interval: Intervallzeit zwischen den Überprüfungen in Sekunden.
        """
        start_time = time.time()
        while time.time() - start_time < timeout:
            if self.checkDataReady():
                return True
            time.sleep(interval)
        raise TimeoutError("Timeout while waiting for data to be ready.")

    def checkErrors(self):
        """Überprüft das Fehlerprotokoll des Geräts"""
        error = self.ask('SYST:ERR?')
        return error
    
    def measure(self):
        """Führt eine Messung durch und verarbeitet die Daten"""
        if(self.isRemoteEnabled()):
            data=np.fromstring(str.rstrip(self.ask(':NUMeric:VALue?')), dtype=np.float32, sep=',')
        else:
            self.enableRemote()
            data=np.fromstring(str.rstrip(self.ask(':NUMeric:VALue?')), dtype=np.float32, sep=',')
        return data
   
        # if(np.isnan(data[0])):
        #         print("NAN value power analyzer")
        #         data=np.fromstring(str.rstrip(self.ask(':NUMeric:VALue?')), dtype=np.float32, sep=',')

