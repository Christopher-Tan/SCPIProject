#Author: Liam Guntli 11.05.2022


from pymeasure.instruments import Instrument

import numpy as np

class HiokiIM3536(Instrument):
    def __init__(self, adapter, delay=0.02, **kwargs):
        super(HiokiIM3536, self).__init__(
            adapter, "HiokiIM3536", **kwargs
        )

    def resetInstrument(self):
        command = "*RST" 
        self.write(command)
    

    def setTrigger(self, source = "INT"):
        command = "TRIG " + source
        self.write(command)

    def getTrigger(self):
        command = "TRIG?"
        return self.ask(command)


    def setRangeAuto(self, status = "ON"):
        command = "RANG " + status
        self.write(command)

    def getRangeAuto(self):
        command = "RANG?"
        return self.ask(command)


    def setMeasurementMode(self, mode = "LCR"):
        command = "MODE " + mode 
        self.write(command)

    def getMeasurementMode(self):
        command = "MODE?"
        return self.ask(command)


    def fileSave(self):
        command = "FILE:SAVE"
        self.write(command)

    def getFileSaveFolder(self):
        command = "FILE:FOLD?"
        return self.ask(command)

    
    def getSystemTime(self):
        command = "SYST:TIME?" 
        return self.ask(command)


    def getID(self):
        command = "*IDN?"
        return self.ask(command)

    
    def getSample(self):
        command = "*TRG"
        return self.ask(command)


    def setMeasurementSpeed(self, speed = "MED"):
        command = "SPEE " + "speed"
        self.write(command)

    def getMeasurementSpeed(self):
        command = "SPEE?"
        return self.ask(command)


    def queryingMeasurementData(self):
        command = "MEAS?"
        return self.ask(command)

    
    def setMeasuringFrequency(self, frequency = "1000"):
        command = "FREQ " + frequency
        self.write(command)

    def getMeasuringFrequency(self):
        command = "FREQ?"
        return self.ask(command)

    def setHeader(self, status = "OFF"):
        command = "HEAD " + status
        self.write(command)
    
    def getHeaderStatus(self):
        command = "HEAD?"
        return self.ask(command)

    
    def setParameter(self, measurement = "0", measure_parameter = ""):
        command = "PAR" + measurement + " " + measure_parameter
        self.write(command)

    
    def setMeasurementSignalLevel(self, level = "V"):
        command = "LEV " + level
        self.write(command)


    def setOpencircuitVoltageLevel(self, voltage = "0.5"):
        command = "LEV:VOLT " + voltage
        self.write(command)


    def setAverage(self, average = "OFF"):
        command = "AVER " + average
        self.write(command)

    def getAverage(self):
        command = "AVER?"
        return self.ask(command)



    


    


    





    